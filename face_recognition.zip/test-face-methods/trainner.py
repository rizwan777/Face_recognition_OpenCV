import os
import numpy as np
from PIL import Image
import cv2

recognizer = cv2.face.LBPHFaceRecognizer_create()
path = 'dataset'

def getImageWithID(path):
    imgPath = [os.path.join(path,f) for f in os.listdir(path)]
    faces = []
    Ids = []
    for imagePath in imgPath:
        faceImg = Image.open(imagePath).convert('L')
        faceNP = np.array(faceImg,'uint8')
        id=int(os.path.split(imagePath)[-1].split('.')[1])
        faces.append(faceNP)
        Ids.append(id)
        cv2.imshow("Training",faceNP)
    return np.array(Ids),faces

Ids,faces = getImageWithID(path)
recognizer.train(faces,Ids)
recognizer.save('recognizer/trainnigData.yml')
cv2.destroyAllWindows()

getImageWithID(path)