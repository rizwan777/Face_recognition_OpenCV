import numpy as np
import cv2
face_detect=cv2.CascadeClassifier('C:/Users/Bond/Desktop/Py_Development/faceRec/testFace/cascades/data/haarcascade_frontalface_default.xml')
cam = cv2.VideoCapture(0)
recognizer = cv2.face.LBPHFaceRecognizer_create()
recognizer.read('recognizer/trainnigData.yml')
id =0
font = cv2.FONT_HERSHEY_SIMPLEX
color = (255, 0, 0)
stroke = 2
#cv2.putText(frame,id,(x,y),font,1,color,stroke,cv2.LINE_AA)

while True:
    ret,frame = cam.read()
    gray = cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)
    faces = face_detect.detectMultiScale (gray,1.3,5)
    for(x,y,w,h) in faces:
        cv2.rectangle(frame,(x,y),(x+w,y+h),(0,0,255),2)
        id,conf = recognizer.predict(gray[y:y+h, x:x+w])
        ##below code you can i write the name of the person on live stream
       ## if conf >= 99:
         ##   cv2.putText(frame, id , (x, y), font, 1, color, stroke, cv2.LINE_AA)


    print(id)
    #"below code for just testing purpose"
    if id==1:
        print("Cao ji jun")
    elif id == 2:
        print("Zhao Tao")
    elif id == 3:
        print(" Michal")
    elif id == 4:
        print("qiaolihong")
    elif id == 5:
        print("Jack-Ma")
    elif id == 6:
        print("Tom-Cruise")
    elif id == 7:
        print("Bond")
    elif id == 8:
        print("Paul Walker")
    elif id == 9:
        print("Selena - Gomez")
    elif id == 10:
        print("Aamir - Khan")
    else:
        print("Unknown")

    cv2.imshow("Face",frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break
cam.release()                                    
cv2.destroyAllWindows()