import numpy as np
import cv2

face_detect=cv2.CascadeClassifier('C:/Users/Bond/Desktop/Py_Development/faceRec/testFace/cascades/data/haarcascade_frontalface_default.xml')
cam = cv2.VideoCapture(0)
id = input("Enter user id")
sampleNumber = 0
while True:
    ret,frame = cam.read()
    gray = cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)
    faces = face_detect.detectMultiScale (gray,1.3,5)
    for(x,y,w,h) in faces:
        sampleNumber = sampleNumber+1
        cv2.imwrite('dataset/user.' +str(id)+'.'+str(sampleNumber)+".jpg",gray[y:y+h,x:x+w])
        cv2.rectangle(frame,(x,y),(x+w,y+h),(0,0,255),2)
    cv2.imshow("Face",frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break
    if(sampleNumber>20):
        break

cam.release()
cv2.destroyAllWindows()